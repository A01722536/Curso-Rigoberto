num1 = 10
num2 = 3

print(num1 + num2) #Opreador suma

print(num1 - num2) #Opreador resta

print(num1 * num2) #Opreador multiplicación

print(num1 / num2) #Opreador división

print(num1 ** num2) #Operador potenciación
print(10**2)

print(num1 // num2) #División entera

print(num1 % 3) #Operador módulo 
print(10 % 2)

print("El módulo {} de {} es: {}".format(num2, num1, (num1 % num2)))

print("El módulo", num2)


