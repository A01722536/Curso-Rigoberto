cantidadPersonas = 100

print(cantidadPersonas)

cantidadPersonas = 150
print(cantidadPersonas)

cantidadPersonas = 780
print(cantidadPersonas)

#Si vemos una variable con mayúsculas, se entiende que es una
#Constante y no se debería modificar
PI = 3.1416

print(PI)