print("Hola mundo") # Imprimir un mensaje

print("Hola, bienvenidos al curso de python")
print('Hola, buenas tardes')

print('Hola, bienvenido a este "nuevo curso"')

#print("Hola, bienvenido a este "nuevo curso"")

