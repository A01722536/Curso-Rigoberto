imprimir = 134
print(imprimir)


#print = 145
#print(print)

import keyword
print(keyword.kwlist)

#No inicializar variables con un número
#30anios = 30
#print(30anios)

#No escribir una variable con caracteres especiales
#ell@s = "ellas y ellos"

#No declarar variables con un espacio en blanco
edad_alumnos = 20
print(edad_alumnos)

#Notación camello
edadJovenes = 34
print(edadJovenes)

#Notación serpiente
EdadJovenes = 19
print(EdadJovenes) 

edadjovenes = 25
print(edadjovenes)

Renglones = """
Bienvenidos a estes curso, el temario es el siguiete:
1. PYthon
2. Pandas
3. NumPy
"""
print(Renglones)