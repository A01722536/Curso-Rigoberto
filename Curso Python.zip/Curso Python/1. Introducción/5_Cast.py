num1 = 40
num2 = 99.99

print(type(num1))
print(num1)

print(type(num2))
print(num2)

print(float(num1))
print(type(float(num1)))

#Casteo a entero no redondea, únicamente mantiene la parte entera
print(int(num2))
print(type(int(num2)))

#Cast implícito
a = 145 # class 'int'
b = 25.34 # Class 'float'

suma = a + b # Class 'float'
print(suma)
print(type(suma))

a = 2.5
b = 2.5

print(type(a+b))

a = 567
b = "354.78"

#suma = a + b #Ocasionar error para demostrar que no se puede la suma
print(suma)

# Conversión de float a int
a = 5.89
a = int(a)
print(a)
print(type(a))

# Conversión de float a string
a = 5.89
a = str(a)
print(a)
print(type(a))

# Conversión de string a float
a = "678.45"
a = float(a)
print(a)
print(type(a))

a = "678,45"
#a = float(a)
print(a)

a = "curso de python"
#a = float(a)
print(a)

# Conversión de int a string 
a = 753
a = str(a)
print(a)
print(type(a))

a = 789
b = "458"
 
print(a + int(b))

suma = a + int(b)