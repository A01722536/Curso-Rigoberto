mensaje = "Hola bienvenido, Ingresa un valor para la variable: " # Mensaje para que aparezca en patalla, Instrucción, petición, solicitud al usuario
#respuesta_usuario = input(mensaje) #Variable para almacenar la respuesta del usuario

#print(respuesta_usuario)
#print(type(respuesta_usuario)) # input siempre devulve tipo 'str'

nombre = input("Escriba su nombre: ")
edad = input("Digite su edad: ")
estatura = input("Digite su estatura: ")

#Imprimir datos capturados
print(nombre, edad, estatura)

print("Hola", nombre, "veo que tienes", edad, "años")

#Método format para cadenas

print( "Hola {} veo que tienes {} años".format(nombre, edad))



