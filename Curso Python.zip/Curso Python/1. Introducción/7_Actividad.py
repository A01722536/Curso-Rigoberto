print("Introduzca 2 números para realizar la suma")

num1 = float(input("Número 1: "))
num2 = float(input("Número 2: "))

resultado = num1 + num2

print("La suma de los dos números es: ", resultado)