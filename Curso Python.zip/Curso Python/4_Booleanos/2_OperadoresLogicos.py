#Operador AND
print(10 > 2 and 9 > 100)

print(10 > 2 and 23 == 23)

#Operador OR

print(99 <= 230 or 60 > 100)

print(99 >= 230 or 60 > 100)

#Operador NOT

print(not 90 != 90)

print(not (99 <= 230 or 60 >100))

### Métodos booleanos para cadenas

cadena = "Estoy mostrando los metodos booleanos para las Strings"
print(cadena.startswith("e"))
print(cadena.endswith("s"))

cadena2 = "SASKLF"
print(cadena2.isupper())
print(cadena2.islower())
