num1 = 1000
num2 = 500
num3 = 1000

print(num1 > num2)

print(num1 < num2)

print(num1 >= num3)

print(num1 <= num3)

print(num1 == num2)

print(num1 != num3) # Operador diferente de...

##Comparación entre cadenas

cadena1 = "Comparaciones de Strings"
cadena2 = "Comparacion de Strings"

print(cadena1 > cadena2)