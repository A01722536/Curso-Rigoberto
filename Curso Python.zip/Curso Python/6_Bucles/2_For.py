lista = ["uno", "dos", "tres"]
print(lista)

for i in lista:
    print(i)

tupla = (1, 2, 3, 4, 5)
for j in tupla:
    print(j)
