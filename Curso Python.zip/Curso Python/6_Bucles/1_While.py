i = 0

while i < 10:
    
    #i = i + 1
    print("Estoy iterando, voy por el salto: ", i)
    i += 1

print("Las iteraciones han finalizado")

###########Contar cuántas veces se puede dividir un número por 2, antes de que sea menor que 1
numero = 64

contador = 0
while numero >= 1:
    numero /= 2
    contador += 1
print("El número puede dividirse por 2,", contador, "veces antes de ser menor que 1")

menu = """
Opción 1
Opción 2
Opción 3
"""
print(menu)

while True: ###Ciclo infinito
    opcion = int(input("Elija la opción que desea: "))
    if opcion == 1:
        print("Bienvenido")
        break
    elif opcion == 2:
        print("Estás en la opción 2")
        break

    elif opcion == 3:
        print("Hasta luego")
        break
    else:
        print("Opción incorrecta")
    