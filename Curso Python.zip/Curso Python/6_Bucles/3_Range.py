for i in range(10):
    print(i)

for j in range(1, 10, 2): ##range(inicio, fin, paso)
    print(j)

frase = "Curso de Python"
for caracter in frase:
    print(caracter)

##########
for i in  range(1, 11):
    print(i)
    if i == 5:
        break

for j in range(1, 11):
    if j == 6:
        continue
    print(j)