numero = int(input("Ingresa un número para saber su tabala: "))

i = 0
multi = 0

while i <= 10:
    multi = numero * i
    print("{} x {} = {}".format(numero, i, multi))
    i += 1

num1 = int(input("Ingresa el primer número: "))
num2 = int(input("Ingresa el segundo número: "))

for i in range(num1, num2 +1):
    if i % 2 == 0:
        continue
    print(i)