#letra = "a"

letra = input("Ingresa una vocal: ")
#if letra == "A":
#    print("Esta vocal es la A")

if letra.lower() == "a": #Método para convertir a minúsculas
    print("Esta vocal es la A")
elif letra.lower() == "e":
    print("Esta vocal es la E")
elif letra.lower() == "i":
    print("Esta vocal es la I")
elif letra.lower() == "o":
    print("Esta vocal es la O")
elif letra.lower() == "u":
    print("Esta vocal es la U")
else: 
    print("Este caracter no es una vocal, intenta de nuevo")
