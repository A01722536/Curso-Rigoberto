nombre = "Juan"
edad = 15

if nombre == "Juan":
    print("Hola, tú eres Juan")

    if edad >= 18:
        print("Eres Juan y eres mayor de edad")
    else:
        print("Eres Juan, pero no eres mayor edad")

else:
    print("Tú no eres Juan, ¿Quién eres?")

#elif edad >= 18:
#    print("Eres mayor de edad")