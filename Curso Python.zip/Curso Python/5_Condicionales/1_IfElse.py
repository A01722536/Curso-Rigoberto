#edad = 15

#print(edad >= 18)

edad = int(input("Digite su edad: "))
if edad >= 18:
    print("Eres mayor de edad. Puedes tener INE")  
else:
    print("Eres menor de edad. No puedes tener INE")  

print("¡Hasta la próxima!")