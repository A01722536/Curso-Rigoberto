cadena = 'estoy uTilizando los metodos De Python'


print(cadena.lower())

print(cadena.capitalize())

print(cadena.title())

print(cadena.swapcase())



#cadena = input("Inserte un dato alfanumérico: ")
if cadena.isalnum():
    print("Has escrito una entrada válida")
else:
    print("Entrada inválida, intenta nuevametne")

##Método Find
email = input("Digita tu e-mail: ")
print(email.find("@"))
if email.find("@") >= 0 and email.find(".") >= 0:
    print("{} Es un e-mail válido".format(email))
else:
    print("Has digitado un e-mail inválido")
