cadena = """
Disfruto programar en C++
C++ es facil de aprender
Llevo programando C++ mas de 2 años
"""
print(cadena)

candena1 = cadena.replace("C++", "Python")
print(candena1)

cadena2 = """El lunes es el primer dia de la semana. 
El lunes es muy productivo. 
Los lunes se entregan tareas"""
print(cadena2)
print(cadena2.replace("lunes", "viernes", 2))
