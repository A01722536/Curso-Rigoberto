cadena = "Este es un ejemplo de Substrings (Devanado de cadenas)"
print(cadena)

#Conocer la longitud de una cadena
print(len(cadena))

print(cadena[3])
print(cadena[53]) #Acceder al último elemento de la cadena

print(cadena[ :8])
print(cadena[0:7])

print(cadena[5:])

#Acceder al último elemento de la cadena
print(cadena[-1])

