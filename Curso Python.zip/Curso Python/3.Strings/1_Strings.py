cadena = "Esto es un ejemplo de cadena de texto"
print(cadena)

#Diagonal invertida es para "escapar caracteres"
cadena = "Esto es un \"  ejemplo de  \" cadena de texto"
print(cadena)

#Barra invertida + n es un salto de línea
cadena = "Esto es un \\n ejemplo de cadena de texto"
print(cadena)

#Barra invertida + t es una tabulación 
cadena = "Esto es un \\t ejemplo de cadena de texto"
print(cadena)

cadena2 = "Rigo"
cadena3 = "Cerino"
numero = 55

#Suma de cadenas, conocida como concatenación
print(cadena2 + cadena3)
print(cadena2, cadena3)

#Multiplicación de cadenas
print(cadena2 * 4)

print("Hola usuario:" + "Profe", cadena2, cadena3)

#Concatenar cadenas con enteros
print("Hola usuario: ", cadena3, numero)
